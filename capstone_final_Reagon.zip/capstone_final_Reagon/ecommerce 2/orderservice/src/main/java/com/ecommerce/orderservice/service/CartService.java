package com.ecommerce.orderservice.service;

import com.ecommerce.orderservice.entity.Cart;

public interface CartService {
    Cart getCartByUserId(Integer userId);
    Cart addProductToCart(Integer userId, Integer productId, Integer quantity);
    Cart clearCart(Integer userId);
    Cart removeProductFromCart(Integer userId, Integer productId);
    Cart updateProductQty(int userId, int productId, int newQty);
}
