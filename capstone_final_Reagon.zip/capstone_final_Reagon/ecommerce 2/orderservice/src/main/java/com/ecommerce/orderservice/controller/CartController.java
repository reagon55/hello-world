package com.ecommerce.orderservice.controller;

import com.ecommerce.orderservice.entity.Cart;
import com.ecommerce.orderservice.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping("/{userId}")
    public Cart getCartByUserId(@PathVariable Integer userId) {
        return cartService.getCartByUserId(userId);
    }

    @PostMapping("/addProd/{userId}/{productId}/{quantity}")
    public Cart addProductToCart(@PathVariable Integer userId,
                                  @PathVariable Integer productId,
                                  @PathVariable Integer quantity) {
        return cartService.addProductToCart(userId, productId, quantity);
    }

    @DeleteMapping("/clear/{userId}")
    public Cart clearCart(@PathVariable Integer userId) {
        return cartService.clearCart(userId);
    }

    @DeleteMapping("/remove/{userId}/{productId}")
    public Cart removeFromCart(@PathVariable Integer userId, @PathVariable Integer productId) {
        return cartService.removeProductFromCart(userId, productId);
    }

    @PutMapping("/updateQty/{userId}/{productId}/{newQty}")
    public ResponseEntity<Cart> updateProductQty(@PathVariable int userId,
                                                 @PathVariable int productId,
                                                 @PathVariable int newQty) {
        Cart updatedCart = cartService.updateProductQty(userId, productId, newQty);
        return ResponseEntity.ok(updatedCart);
    }


}
