package com.ecommerce.orderservice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProductDTO {

    private Integer id;

    @JsonProperty("prodName")
    private String prodName;

    @JsonProperty("availableQty")
    private int availableQty;

    @JsonProperty("price")
    private double price;

    // Add other fields if needed, with matching @JsonProperty if the names differ

    // Getters and setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getAvailableQty() {
        return availableQty;
    }

    public void setAvailableQty(int availableQty) {
        this.availableQty = availableQty;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "ProductDTO{" +
                "id=" + id +
                ", prodName='" + prodName + '\'' +
                ", availableQty=" + availableQty +
                ", price=" + price +
                '}';
    }
}
