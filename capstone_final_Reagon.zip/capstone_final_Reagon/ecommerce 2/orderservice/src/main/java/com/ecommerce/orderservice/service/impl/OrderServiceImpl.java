package com.ecommerce.orderservice.service.impl;

import com.ecommerce.orderservice.entity.Cart;
import com.ecommerce.orderservice.entity.Order;
import com.ecommerce.orderservice.repository.CartRepository;
import com.ecommerce.orderservice.repository.OrderRepository;
import com.ecommerce.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    @Override
    public Order placeOrder(Integer userId) {
        // 1. Fetch the cart for the user
        Cart cart = cartRepository.findByUserId(userId);
        if (cart == null || cart.getProductDetails().isEmpty()) {
            throw new RuntimeException("Cart is empty. Cannot place order.");
        }

        // 2. Prepare order details
        Double amount = cart.getTotalPrice();  //
        Order order = new Order();
        order.setUserId(userId);
        order.setProductQuantityMap(new HashMap<>(cart.getProductDetails()));
        order.setTotalAmount(amount);  //
        order.setOrderStatus("CONFIRMED");
        order.setOrderDate(LocalDateTime.now());

        // 3. Save order to DB
        Order savedOrder = orderRepository.save(order);

        // 4. Clear the cart after placing order
        cart.setProductDetails(new HashMap<>());
        cart.setTotalQty(0.0);
        cart.setTotalPrice(0.0);
        cartRepository.save(cart);

        return savedOrder;
    }



    @Override
    public List<Order> getOrdersByUserId(Integer userId) {
        return orderRepository.findByUserId(userId);
    }




}
