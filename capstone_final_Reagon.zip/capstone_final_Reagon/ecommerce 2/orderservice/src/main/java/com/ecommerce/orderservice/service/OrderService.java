package com.ecommerce.orderservice.service;

import com.ecommerce.orderservice.entity.Order;

import java.util.List;

public interface OrderService {
    Order placeOrder(Integer userId);
    List<Order> getOrdersByUserId(Integer userId);

}
