package com.ecommerce.orderservice.service.impl;

import com.ecommerce.orderservice.dto.ProductDTO;
import com.ecommerce.orderservice.entity.Cart;
import com.ecommerce.orderservice.repository.CartRepository;
import com.ecommerce.orderservice.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;


    @Override
    public Cart getCartByUserId(Integer userId) {
        Cart cart = cartRepository.findByUserId(userId);
        if(cart == null) {
            throw new RuntimeException("Cart not found for userid: " +userId);
        }
        return cart;
    }
    @Override
    public Cart removeProductFromCart(Integer userId, Integer productId) {
        Cart cart = cartRepository.findByUserId(userId);

        if (cart == null) {
            throw new RuntimeException("Cart not found for userId: " + userId);
        }

        if (!cart.getProductDetails().containsKey(productId)) {
            throw new RuntimeException("Product ID " + productId + " not found in cart");
        }

        cart.getProductDetails().remove(Integer.valueOf(productId));
        return cartRepository.save(cart);
    }



    @Override
    public Cart addProductToCart(Integer userId, Integer prodId, Integer qty) {
        // Step 1: Fetch or create cart
        Cart cart = cartRepository.findByUserId(userId);
                if(cart == null) {
                    cart = new Cart();
                    cart.setUserId((userId));
                    cart.setProductDetails(new HashMap<>());
                }

        cart.getProductDetails().put(prodId, qty);

        // Step 2: Fetch product info from Product microservice
        ProductDTO product = null;
        try {
            product = webClientBuilder.build()
                    .get()
                    .uri("http://localhost:8087/product/" + prodId)
                    .retrieve()
                    .bodyToMono(ProductDTO.class)
                    .block();

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch product details: " + e.getMessage());
        }

        if (product == null) {
            throw new RuntimeException("Product not found from ProductService.");
        }

        // Step 3: Validate product availability
        int availableQty = product.getAvailableQty();
        System.out.println("Fetched Product : " + product);
        System.out.println("Available Qty : " +product.getAvailableQty());
        if (availableQty < qty) {
            throw new RuntimeException("Only " + availableQty + " units available. You are trying to add " + qty);
        }

        // Step 4: Save the updated cart
        cart.setTotalQty(Double.valueOf(qty));
        cart.setTotalPrice(qty * product.getPrice());
        return cartRepository.save(cart);
    }

    @Override
    public Cart clearCart(Integer userId) {
        return null;
    }

    @Override
    public Cart updateProductQty(int userId, int productId, int newQty) {
        Cart cart = cartRepository.findByUserId(userId);
        if (cart == null) {
            throw new RuntimeException("Cart not found for user: " + userId);
        }

        // Step 1: Update product quantity or remove
        if (newQty <= 0) {
            cart.getProductDetails().remove(productId);
        } else {
            cart.getProductDetails().put(productId, newQty);
        }

        // Step 2: Recalculate totalQty
        int totalQty = cart.getProductDetails().values()
                .stream()
                .mapToInt(Integer::intValue)
                .sum();

        // Step 3: Calculate totalPrice using BigDecimal
        BigDecimal totalPrice = BigDecimal.ZERO;
        for (Map.Entry<Integer, Integer> entry : cart.getProductDetails().entrySet()) {
            int prodId = entry.getKey();
            int qty = entry.getValue();

            ProductDTO product = webClientBuilder.build().get()
                    .uri("http://localhost:8087/product/" + prodId)
                    .retrieve()
                    .bodyToMono(ProductDTO.class)
                    .block();

            BigDecimal price = BigDecimal.valueOf(product.getPrice());
            totalPrice = totalPrice.add(price.multiply(BigDecimal.valueOf(qty)));
        }

        // Step 4: Set updated totals and return cart
        cart.setTotalQty((double) totalQty);
        cart.setTotalPrice(totalPrice.setScale(2, RoundingMode.HALF_UP).doubleValue());

        System.out.println("Updated Cart Details: " + cart.getProductDetails());
        System.out.println("Final Total Price: " + cart.getTotalPrice());

        return cartRepository.save(cart);
    }





}
