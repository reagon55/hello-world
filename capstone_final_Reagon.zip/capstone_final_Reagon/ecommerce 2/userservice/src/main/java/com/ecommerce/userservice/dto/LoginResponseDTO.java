package com.ecommerce.userservice.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data

public class LoginResponseDTO {
    private String token;

    private String userId;
    private Integer id;

    private int userType;
    private String firstName;
    private boolean isLoggedIn;


    public LoginResponseDTO(String token, String userId, Integer id, int userType, String firstName, boolean isLoggedIn) {
        this.token = token;
        this.userId = userId;
        this.id = id;
        this.userType = userType;
        this.firstName = firstName;
        this.isLoggedIn = isLoggedIn;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
    }
}
