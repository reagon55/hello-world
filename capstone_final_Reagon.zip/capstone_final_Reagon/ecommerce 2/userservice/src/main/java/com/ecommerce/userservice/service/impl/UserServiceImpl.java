package com.ecommerce.userservice.service.impl;

import com.ecommerce.userservice.dto.LoginRequestDTO;
import com.ecommerce.userservice.dto.LoginResponseDTO;
import com.ecommerce.userservice.entity.User;
import com.ecommerce.userservice.repo.UserRepository;
import com.ecommerce.userservice.security.JwtUtil;
import com.ecommerce.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public LoginResponseDTO login(LoginRequestDTO dto) {
        User user = userRepo.findByUserIdAndPassword(dto.getUserId(), dto.getPassword())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        user.setLoggedIn(true);


        userRepo.save(user);

        String token = jwtUtil.generateToken(user.getUserId());

        return new LoginResponseDTO(
                token,
                user.getUserId(),
                user.getId(),
                user.getUserType(),
                user.getFirstName(),
                user.isLoggedIn()
        );
    }

    @Override
    public String logout(String userId) {
        Optional<User> optionalUser = userRepo.findAll().stream()
                .filter(u -> u.getUserId().equals(userId))
                .findFirst();

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            user.setLoggedIn(false);
            userRepo.save(user);
            return "Logged out successfully";
        }
        return "User not found";
    }

    @Override
    public User createUser(User user) {
        user.setLoggedIn(false);
        return userRepo.save(user);
    }

    @Override
    public User updateUser(User user) {
        return userRepo.save(user);
    }

    @Override
    public String deleteUser(User user) {
        userRepo.delete(user);
        return "User deleted";
    }

    @Override
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    @Override
    public User getUserById(int id) {
        return userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public List<String> getMenuByUserId(int id) {
        User user = getUserById(id);
        if (user.getUserType() == 0) {
            return List.of("User Management", "Product Management", "Order Management");
        } else {
            return List.of("Browse Products", "View Cart", "Track Orders");
        }
    }
}
