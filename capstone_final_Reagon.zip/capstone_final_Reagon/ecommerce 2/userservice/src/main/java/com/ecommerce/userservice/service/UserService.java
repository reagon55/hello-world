package com.ecommerce.userservice.service;

import com.ecommerce.userservice.dto.LoginRequestDTO;
import com.ecommerce.userservice.dto.LoginResponseDTO;
import com.ecommerce.userservice.entity.User;
import com.ecommerce.userservice.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface UserService {
    User createUser(User user);
    User updateUser(User user);
    String deleteUser(User user);
    List<User> getAllUsers();
    User getUserById(int id);
    List<String> getMenuByUserId(int id);
    LoginResponseDTO login(LoginRequestDTO dto);
    String logout(String userId);
}
