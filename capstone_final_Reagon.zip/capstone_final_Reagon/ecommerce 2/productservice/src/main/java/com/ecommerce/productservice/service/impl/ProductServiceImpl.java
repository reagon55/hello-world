package com.ecommerce.productservice.service.impl;

import com.ecommerce.productservice.entity.Product;
import com.ecommerce.productservice.repository.ProductRepository;
import com.ecommerce.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public Product updateProduct(Product updatedProduct) {
        Optional<Product> optionalProduct = productRepository.findById(updatedProduct.getId());

        if (optionalProduct.isPresent()) {
            Product existingProduct = optionalProduct.get();
            existingProduct.setProdName(updatedProduct.getProdName());
            existingProduct.setProdDesc(updatedProduct.getProdDesc());
            existingProduct.setProdCat(updatedProduct.getProdCat());
            existingProduct.setMake(updatedProduct.getMake());
            existingProduct.setAvailableQty(updatedProduct.getAvailableQty());
            existingProduct.setPrice(updatedProduct.getPrice());
            existingProduct.setProdRating(updatedProduct.getProdRating());
            existingProduct.setImageUrl(updatedProduct.getImageUrl());
            existingProduct.setDateOfManufacture(updatedProduct.getDateOfManufacture());

            return productRepository.save(existingProduct);
        } else {
            throw new RuntimeException("Product with ID " + updatedProduct.getId() + " not found.");
        }
    }

    @Override
    public void deleteProduct(int id) {
        if (!productRepository.existsById(id)) {
            throw new RuntimeException("Product not found with ID: " + id);
        }
        productRepository.deleteById(id);
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product getProductById(int id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + id));
    }

    @Override
    public List<Product> getProductsByCategory(String category) {
        return productRepository.findAll().stream()
                .filter(p -> p.getProdCat().equalsIgnoreCase(category))
                .toList();
    }

    @Override
    public void updateImageUrl(int id, String imageUrl) {
        Optional<Product> optionalProduct = productRepository.findById(id);
        if (optionalProduct.isPresent()) {
            Product prod = optionalProduct.get();
            prod.setImageUrl(imageUrl);
            productRepository.save(prod);
        } else {
            throw new RuntimeException("Product not found with ID: " + id);
        }
    }

}
