package com.ecommerce.productservice.service;

import com.ecommerce.productservice.entity.Product;
import java.util.List;

public interface ProductService {
    Product addProduct(Product product);
    Product updateProduct(Product product);
    void deleteProduct(int id);
    List<Product> getAllProducts();
    Product getProductById(int id);
    List<Product> getProductsByCategory(String category);
    void updateImageUrl(int id, String imageUrl);

}
