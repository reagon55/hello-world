import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const LoginPage: React.FC = () => {
  const [loginData, setLoginData] = useState({
    userId: "",
    password: ""
  });

  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLoginData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:8085/user/login", loginData);
      const { token, userId, userType, id } = response.data;

      // Store login info
      localStorage.setItem("token", token);
      localStorage.setItem("userName", userId)
      localStorage.setItem("userId", id.toString());
      localStorage.setItem("userType", userType);
      localStorage.setItem("id", id);
      sessionStorage.setItem("isLoggedIn", "true");

      toast.success("Login successful!");

      if (userType === 0 || userType === "0") {
        navigate("/add-product");
      } else {
        navigate("/home");
      }
    } catch (err) {
      console.error("Login failed:", err);
      toast.error("Invalid credentials. Please try again.");
    }
  };

  return (
    <div className="bg-dark text-light min-vh-100 py-5">
      <div className="container mt-5">
        <h2 className="mb-4">Login</h2>
        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label">User ID</label>
            <input
              type="text"
              name="userId"
              className="form-control"
              value={loginData.userId}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Password</label>
            <input
              type="password"
              name="password"
              className="form-control"
              value={loginData.password}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-success">Login</button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
