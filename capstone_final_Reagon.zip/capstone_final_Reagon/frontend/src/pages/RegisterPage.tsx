import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const RegisterPage: React.FC = () => {
  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    emailId: "",
    userId: "",
    password: "",
    address: "",
    userType: "1", // 0 = admin, 1 = customer
  });

  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUser((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:8085/user/register", user);
      console.log("User registered:", response.data);
      alert("Registration successful! Please login.");
      navigate("/login");
    } catch (err) {
      console.error("Registration error:", err);
      alert("Registration failed. Try again.");
    }
  };

  return (
    <div className="bg-dark text-light min-vh-100 py-5">
      <div className="container">
    <div className="container mt-5">
      <h2 className="mb-4">Register</h2>
      <div className="text-end mb-3">
  <button
    className="btn btn-outline-primary"
    onClick={() => navigate("/login")}
    type="button"
  >
    Login
  </button>
</div>

      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="mb-3 col-md-6">
            <label className="form-label">First Name</label>
            <input type="text" name="firstName" className="form-control" onChange={handleChange} required />
          </div>
          <div className="mb-3 col-md-6">
            <label className="form-label">Last Name</label>
            <input type="text" name="lastName" className="form-control" onChange={handleChange} required />
          </div>
        </div>
        <div className="mb-3">
          <label className="form-label">Email ID</label>
          <input type="email" name="emailId" className="form-control" onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">User ID</label>
          <input type="text" name="userId" className="form-control" onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input type="password" name="password" className="form-control" onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Address</label>
          <input type="text" name="address" className="form-control" onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">User Type</label>
          <select name="userType" className="form-select" onChange={handleChange} required>
            <option value="1">Customer</option>
            <option value="0">Admin</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary">Register</button>
      </form>
    </div>
    </div>
    </div>
  );
};

export default RegisterPage;
