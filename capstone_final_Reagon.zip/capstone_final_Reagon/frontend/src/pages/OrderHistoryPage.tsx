import React, { useEffect, useState } from "react";
import axios from "axios";
import type { Prod } from "../models/Prod";

interface Order {
  id: number;
  userId: number;
  productQuantityMap: { [key: string]: number };
  totalQty: number;
  totalPrice: number;
  orderStatus: string;
  orderDate: string;
}

const OrderHistoryPage = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [productMap, setProductMap] = useState<{ [key: string]: Prod }>({});
  const userIdStr = localStorage.getItem("userId");
  const userId = userIdStr ? Number(userIdStr) : null;

  useEffect(() => {
    if (!userId) {
      alert("Please login first to view order history");
      return;
    }

    axios
      .get(`http://localhost:8083/order/orders/${userId}`)
      .then((res) => setOrders(res.data))
      .catch(() => alert("Failed to fetch order history"));

    const fetchProducts = async () => {
      try {
        const res = await axios.get("http://localhost:8087/product");
        const map: Record<string, Prod> = {};
        res.data.forEach((prod: Prod) => {
          map[prod.id.toString()] = prod;
        });
        setProductMap(map);
      } catch (err) {
        console.error("Failed to fetch products");
      }
    };

    fetchProducts();
  }, []);

  return (
    <div className="container bg-dark text-white min-vh-100 py-4">
      <h2 className="text-info mb-4">My Orders</h2>
      {orders.length === 0 ? (
        <p>No past orders found.</p>
      ) : (
        <ul className="list-group bg-dark">
          {orders.map((order) => (
            <li
              key={order.id}
              className="list-group-item bg-secondary text-white mb-3 rounded"
            >
              <strong>Order ID:</strong> {order.id}
              <br />
              <strong>Items:</strong>
              <ul>
                {Object.entries(order.productQuantityMap || {}).map(
                  ([prodId, qty]) => {
                    const product = productMap[prodId];
                    return product ? (
                      <li key={`${order.id}-${prodId}`}>
                        {product.prodName} × {qty} (₹{product.price})
                      </li>
                    ) : (
                      <li key={`${order.id}-${prodId}`}>Loading...</li>
                    );
                  }
                )}
              </ul>
              <strong>Total Qty:</strong> {order.totalQty} <br />
              <strong>Total Price:</strong> ₹{order.totalPrice} <br />
              <strong>Date:</strong>{" "}
              {new Date(order.orderDate).toLocaleString()}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default OrderHistoryPage;
