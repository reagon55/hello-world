import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import type { Prod } from '../models/Prod';

const AddProduct: React.FC = () => {
  const navigate = useNavigate();
  const [product, setProduct] = useState<Prod>({
    id: 0,
    prodName: '',
    prodDesc: '',
    prodCat: '',
    make: '',
    price: 0,
    availableQty: 0,
    wom: '',
    prodRating: 0,
    imageUrl: '',
    dateOfManufacture: '',
  });

  useEffect(() => {
    const userType = localStorage.getItem('userType');
    if (userType !== '0') {
      toast.error("Access denied. Admin only.");
      navigate('/home');
    }
  }, [navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProduct(prev => ({
      ...prev,
      [name]: name === 'price' || name === 'availability' || name === 'rating' ? Number(value) : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:8082/product', product, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      toast.success('Product added successfully');
      navigate('/home');
    } catch (error) {
      toast.error('Failed to add product');
      console.error(error);
    }
  };

  return (
    <div className="container vh-100 d-flex align-items-center justify-content-center">
      <form onSubmit={handleSubmit} className="bg-dark text-light p-4 rounded w-50 shadow">
        <h3 className="text-center mb-4">Add Product</h3>

        <div className="mb-3">
          <label>Product Name</label>
          <input type="text" name="prodName" className="form-control" value={product.prodName} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label>Description</label>
          <input type="text" name="prodDesc" className="form-control" value={product.prodDesc} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label>Category</label>
          <select name="prodCat" className="form-control" value={product.prodCat} onChange={handleChange} required>
            <option value="">--Select Category--</option>
            <option value="Electronics">Electronics</option>
            <option value="Kitchen">Kitchen</option>
            <option value="Fashion">Fashion</option>
            <option value="Home Appliances">Home Appliances</option>
          </select>
        </div>

        <div className="mb-3">
          <label>Make</label>
          <input type="text" name="make" className="form-control" value={product.make} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label>Price</label>
          <input type="number" name="price" className="form-control" value={product.price} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label>Availability</label>
          <input type="number" name="availability" className="form-control" value={product.availableQty} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label>Warranty</label>
          <input type="text" name="warranty" className="form-control" value={product.wom} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label>Rating</label>
          <input type="number" name="rating" className="form-control" value={product.prodRating} onChange={handleChange} required />
        </div>

        <div className="mb-3">
          <label>Image URL</label>
          <input type="text" name="imageURL" className="form-control" value={product.imageUrl} onChange={handleChange} required />
        </div>

        <div className="mb-4">
          <label>Date of Manufacture</label>
          <input type="date" name="dateOfManufacture" className="form-control" value={product.dateOfManufacture} onChange={handleChange} required />
        </div>

        <button type="submit" className="btn btn-success w-100">Add Product</button>
      </form>
    </div>
  );
};

export default AddProduct;
