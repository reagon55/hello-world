import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import type { Prod } from "../models/Prod";

interface CartItem {
  product: Prod;
  quantity: number;
}

const CartPage: React.FC = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [totalQty, setTotalQty] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);
  const navigate = useNavigate();

  const token = localStorage.getItem("token");
  const userIdStr = localStorage.getItem("id");
  const userId = userIdStr ? Number(userIdStr) : null;

  useEffect(() => {
    if (!token || !userId) {
      alert("Please login first to view cart");
      navigate("/login");
      return;
    }
    fetchCart();
  }, []);

  const fetchCart = async () => {
    try {
      const res = await axios.get(`http://localhost:8083/cart/${userId}`);
      const cartData = res.data.productDetails; // { productId: qty }

      const productPromises = Object.keys(cartData).map(async (prodId) => {
        const prodRes = await axios.get(`http://localhost:8087/product/${prodId}`);
        return {
          product: prodRes.data,
          quantity: cartData[prodId],
        };
      });

      const items = await Promise.all(productPromises);
      setCartItems(items);

      const qty = items.reduce((sum, item) => sum + item.quantity, 0);
      const price = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
      setTotalQty(qty);
      setTotalPrice(price);
    } catch (err) {
      toast.error("Failed to fetch cart");
    }
  };

  const handleRemove = (productId: number) => {
    axios
      .delete(`http://localhost:8083/cart/remove/${userId}/${productId}`)
      .then(() => {
        toast.success("Product removed from cart!");
        fetchCart(); // Refresh cart data
      })
      .catch(() => toast.error("Failed to remove product"));
  };

  const handleSubmitOrder = async () => {
    try {
      await axios.post(`http://localhost:8083/order/place/${userId}`);
      toast.success("Order placed successfully!");
      navigate("/home");
    } catch (err) {
      toast.error("Failed to place order");
    }
  };

  const handleUpdateQty = async (productId: number, newQty: number) => {
    try {
      if (newQty <= 0) {
        await axios.delete(`http://localhost:8083/cart/remove/${userId}/${productId}`);
      } else {
        await axios.put(`http://localhost:8083/cart/updateQty/${userId}/${productId}/${newQty}`);
      }
      fetchCart(); // Refresh
    } catch (err) {
      toast.error("Failed to update quantity");
    }
  };

  return (
    <div className="container bg-dark text-white min-vh-100 py-4">
      <h3 className="text-warning text-center">🛒 Your Cart</h3>
      {cartItems.length === 0 ? (
        <p className="text-center mt-4">No items in cart</p>
      ) : (
        <>
          <ul className="list-group mt-4">
            {cartItems.map((item) => (
              <li
                key={item.product.id}
                className="list-group-item d-flex flex-column flex-md-row justify-content-between align-items-center bg-secondary text-white mb-2"
              >
                <div className="d-flex flex-column flex-md-row align-items-md-center gap-4 w-100 justify-content-between">
                  <div>
                    <strong>{item.product.prodName}</strong>
                    <div>Price: ₹{item.product.price.toFixed(2)}</div>
                  </div>

                  <div className="d-flex align-items-center gap-2">
                    <button
                      className="btn btn-sm btn-outline-light"
                      onClick={() => handleUpdateQty(item.product.id, item.quantity - 1)}
                      disabled={item.quantity <= 1}
                    >
                      -
                    </button>
                    <span>{item.quantity}</span>
                    <button
                      className="btn btn-sm btn-outline-light"
                      onClick={() => handleUpdateQty(item.product.id, item.quantity + 1)}
                    >
                      +
                    </button>
                  </div>

                  <div>= ₹{(item.product.price * item.quantity).toFixed(2)}</div>

                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => handleRemove(item.product.id)}
                  >
                    Remove
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <div className="text-end mt-4">
            <h5>Total Qty: {totalQty}</h5>
            <h5>Total Price: ₹{totalPrice.toLocaleString()}</h5>
            <button className="btn btn-success mt-3" onClick={handleSubmitOrder}>
               Submit Order
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default CartPage;
