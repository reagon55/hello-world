import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import type { Prod } from "../models/Prod";
import ProductCard from "../components/ProductCard";
import { toast } from "react-toastify";

const HomePage: React.FC = () => {
  const [products, setProducts] = useState<Prod[]>([]);
  const [groupedProducts, setGroupedProducts] = useState<{ [key: string]: Prod[] }>({});
  const [cartCount, setCartCount] = useState(0);
  const navigate = useNavigate();

  const isLoggedIn = localStorage.getItem("token") !== null;

  // Use DB ID
  const userIdStr = localStorage.getItem("id");
  const userId = userIdStr ? Number(userIdStr) : null;

  const userName = localStorage.getItem("userId");

  const userLoggedIn = localStorage.getItem("userName");

  const fetchProducts = async () => {
    try {
      const res = await axios.get("http://localhost:8087/product");
      setProducts(res.data);

      const grouped: { [key: string]: Prod[] } = {};
      res.data.forEach((product: Prod) => {
        const cat = product.prodCat || "Uncategorized";
        if (!grouped[cat]) grouped[cat] = [];
        grouped[cat].push(product);
      });

      setGroupedProducts(grouped);
    } catch (err) {
      console.error("Failed to load products", err);
    }
  };

  const handleLogin = () => navigate("/login");
  const handleRegister = () => navigate("/register");

  const handleViewCart = () => {
    if (!isLoggedIn || userId === null) {
      toast.warning("Please login first to view cart");
      navigate("/login");
    } else {
      navigate("/cart");
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = "/home";
  };

  const handleAddToCart = () => {
    setCartCount((prev) => prev + 1);
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div className="bg-dark text-white min-vh-100">
      <nav className="navbar navbar-dark bg-primary px-4 d-flex justify-content-between">
        <h4 className="text-light">Mini ECommerce Application</h4>
        <div>
          {isLoggedIn && (

          <button className="btn btn-success me-3" onClick={handleViewCart}>
          View Cart ({cartCount})
          </button>
          )
         }

{isLoggedIn && (
  <button className="btn btn-info me-2" onClick={() => navigate("/orders")}>
    My Orders
  </button>
)}
          
          {isLoggedIn ? (
            <button className="btn btn-danger" onClick={handleLogout}>
              Logout
            </button>
          ) : (
            <>
              <button className="btn btn-outline-light me-2" onClick={handleLogin}>
                Login
              </button>
              <button className="btn btn-outline-light" onClick={handleRegister}>
                Register
              </button>
            </>
          )}
        </div>
      </nav>

      <div className="container mt-4">
        {userName && (
          <h4 className="text-warning mb-4">Welcome {userLoggedIn}</h4>
        )}
        {Object.keys(groupedProducts).map((category) => (
          <div key={category} className="mb-5">
            <h5 className="text-warning">{category}</h5>
            <div className="d-flex flex-wrap gap-3">
              {groupedProducts[category].map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
