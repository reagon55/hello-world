// src/models/Prod.ts

export interface Prod {
    id: number;
    prodName: string;
    prodDesc: string;
    prodCat: string;
    make: string;
    availableQty: number;
    price: number;
    wom: string; // warranty or warranty period
    prodRating: number;
    imageUrl: string;
    dateOfManufacture: string; // should be in ISO format from backend
  }
  