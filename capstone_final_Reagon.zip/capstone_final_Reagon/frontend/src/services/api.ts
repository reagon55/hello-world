import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8085", // API Gateway URL
  withCredentials: true,
});

export default api;