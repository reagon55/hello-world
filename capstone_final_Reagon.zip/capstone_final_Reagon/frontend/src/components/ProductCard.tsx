import React from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import type { Prod } from "../models/Prod";

interface ProductCardProps {
  product: Prod;
  onAddToCart: () => void; // updated the props for add to cart event
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  const navigate = useNavigate();

  const handleAddToCart = () => {
    const token = localStorage.getItem("token");
    //const userId = localStorage.getItem("id"); // exact DB ID
    const userIdStr = Number(localStorage.getItem("userId"));
    const userId = userIdStr ? Number(userIdStr) : null;
    if (!token || !userId) {
      toast.warning("Please login first to add to cart!");
      navigate("/login");
      return;
    }

    const url = `http://localhost:8083/cart/addProd/${userId}/${product.id}/1`;
    console.log("Sending to backend:", { userId, productId: product.id });

    axios
      .post(url)
      .then(() => {
       toast.success(`${product.prodName} added to cart!`);
       onAddToCart(); // Trigger increment
      })
      .catch(() => toast.error("Failed to add product to cart"));
      
  };

  return (
    <div className="card" style={{ width: "18rem" }}>
      <img src={product.imageUrl} className="card-img-top" alt={product.prodName} />
      <div className="card-body">
        <h5 className="card-title">{product.prodName}</h5>
        <p className="card-text">Price: ₹{product.price.toLocaleString()}</p>
        <button className="btn btn-primary" onClick={handleAddToCart}>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
