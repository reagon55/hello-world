package com.yourapp.orderservice.controller;

import com.yourapp.orderservice.model.Cart;
import com.yourapp.orderservice.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/addProd/{userId}/{prodId}/{qty}")
    public ResponseEntity<Cart> addToCart(@PathVariable int userId,
                                          @PathVariable int prodId,
                                          @PathVariable int qty) {
        return ResponseEntity.ok(cartService.addProductToCart(userId, prodId, qty));
    }

    @GetMapping("/view/{userId}")
    public ResponseEntity<Cart> viewCart(@PathVariable int userId) {
        return ResponseEntity.ok(cartService.getCartByUserId(userId));
    }
}
