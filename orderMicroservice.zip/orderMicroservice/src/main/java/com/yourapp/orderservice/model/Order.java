package com.yourapp.orderservice.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Entity
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    private int userId;

    @ElementCollection
    private Map<Integer, Integer> productQuantityMap = new HashMap<>();

    private double totalAmount;
    private String orderStatus;
    private LocalDateTime orderDate;

    // Getters and Setters
}
