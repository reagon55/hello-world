package com.yourapp.orderservice.service;

import com.yourapp.orderservice.model.Cart;
import com.yourapp.orderservice.model.Order;
import com.yourapp.orderservice.repository.CartRepository;
import com.yourapp.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    public Order placeOrder(int userId) {
        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));

        Order order = new Order();
        order.setUserId(userId);
        order.setProductQuantityMap(cart.getProductDetails());
        order.setTotalAmount(cart.getTotalPrice());
        order.setOrderDate(LocalDateTime.now());
        order.setOrderStatus("CONFIRMED");

        orderRepository.save(order);
        cartRepository.delete(cart);

        return order;
    }
}
