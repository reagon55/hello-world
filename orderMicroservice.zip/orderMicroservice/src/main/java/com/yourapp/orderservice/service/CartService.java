package com.yourapp.orderservice.service;

import com.yourapp.orderservice.model.Cart;
import com.yourapp.orderservice.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private RestTemplate restTemplate;

    public Cart addProductToCart(int userId, int productId, int qty) {
        Cart cart = cartRepository.findByUserId(userId).orElse(new Cart());
        cart.setUserId(userId);

        Map<Integer, Integer> productDetails = cart.getProductDetails();
        productDetails.put(productId, productDetails.getOrDefault(productId, 0) + qty);

        Double price = restTemplate.getForObject("http://localhost:8081/product/price/" + productId, Double.class);

        cart.setTotalQty(cart.getTotalQty() + qty);
        cart.setTotalPrice(cart.getTotalPrice() + (price * qty));

        return cartRepository.save(cart);
    }

    public Cart getCartByUserId(int userId) {
        return cartRepository.findByUserId(userId).orElse(null);
    }

    public void clearCart(int userId) {
        cartRepository.findByUserId(userId).ifPresent(cartRepository::delete);
    }
}
