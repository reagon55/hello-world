package com.yourapp.orderservice.model;

import jakarta.persistence.*;
import java.util.HashMap;
import java.util.Map;

@Entity
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private int userId;

    @ElementCollection
    private Map<Integer, Integer> productDetails = new HashMap<>();

    private int totalQty;
    private double totalPrice;

    // Getters and Setters
}
