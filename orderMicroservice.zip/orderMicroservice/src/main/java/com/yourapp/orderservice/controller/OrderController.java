package com.yourapp.orderservice.controller;

import com.yourapp.orderservice.model.Order;
import com.yourapp.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/place/{userId}")
    public ResponseEntity<Order> placeOrder(@PathVariable int userId) {
        return ResponseEntity.ok(orderService.placeOrder(userId));
    }
}
