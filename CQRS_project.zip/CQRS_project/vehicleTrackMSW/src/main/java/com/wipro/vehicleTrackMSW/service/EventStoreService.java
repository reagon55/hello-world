package com.wipro.vehicleTrackMSW.service;

import com.wipro.vehicleTrackMSW.entity.EventStore;
import com.wipro.vehicleTrackMSW.repository.EventStoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class EventStoreService {

    @Autowired
    private EventStoreRepository eventStoreRepository;

    public EventStore addEvent(EventStore eventStore) {
        eventStore.setEvent("moving"); // Fix event name
        eventStore.setTimestamp(LocalDateTime.now()); // Set current time
        return eventStoreRepository.save(eventStore);
    }
}
