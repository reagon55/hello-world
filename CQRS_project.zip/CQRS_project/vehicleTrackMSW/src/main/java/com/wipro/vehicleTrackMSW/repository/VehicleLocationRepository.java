package com.wipro.vehicleTrackMSW.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.wipro.vehicleTrackMSW.entity.VehicleLocation;

public interface VehicleLocationRepository extends JpaRepository<VehicleLocation, Integer> {

}
