package com.wipro.vehicleTrackMSW.service;

import com.wipro.vehicleTrackMSW.entity.VehicleLocation;
import com.wipro.vehicleTrackMSW.repository.VehicleLocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleLocationService {

    @Autowired
    private VehicleLocationRepository vehicleLocationRepository;

    public VehicleLocation saveLocation(VehicleLocation vehicleLocation) {
        return vehicleLocationRepository.save(vehicleLocation);
    }
}
