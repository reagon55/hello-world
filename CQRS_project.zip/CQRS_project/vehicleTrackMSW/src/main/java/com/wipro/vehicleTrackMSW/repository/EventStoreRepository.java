package com.wipro.vehicleTrackMSW.repository;

import com.wipro.vehicleTrackMSW.entity.EventStore;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventStoreRepository extends JpaRepository<EventStore, Integer> {
}
