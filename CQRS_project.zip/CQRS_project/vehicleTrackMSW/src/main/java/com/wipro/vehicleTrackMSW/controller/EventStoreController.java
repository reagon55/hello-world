package com.wipro.vehicleTrackMSW.controller;

import com.wipro.vehicleTrackMSW.entity.EventStore;
import com.wipro.vehicleTrackMSW.service.EventStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/event")
public class    EventStoreController {

    @Autowired
    private EventStoreService eventStoreService;

    @PostMapping("/add")
    public EventStore addEvent(@RequestBody EventStore eventStore) {
        return eventStoreService.addEvent(eventStore);
    }
}
