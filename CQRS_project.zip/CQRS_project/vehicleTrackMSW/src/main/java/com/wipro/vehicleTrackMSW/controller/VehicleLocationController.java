package com.wipro.vehicleTrackMSW.controller;

import com.wipro.vehicleTrackMSW.entity.VehicleLocation;
import com.wipro.vehicleTrackMSW.service.VehicleLocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/vehicle")
public class VehicleLocationController {

    @Autowired
    private VehicleLocationService vehicleLocationService;

    @PostMapping("/add")
    public VehicleLocation addLocation(@RequestBody VehicleLocation vehicleLocation) {
        return vehicleLocationService.saveLocation(vehicleLocation);
    }
}
