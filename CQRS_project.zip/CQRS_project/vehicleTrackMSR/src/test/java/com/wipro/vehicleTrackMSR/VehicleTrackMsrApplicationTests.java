package com.wipro.vehicleTrackMSR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleTrackMsrApplicationTests {

	@Test
	void contextLoads() {
	}

}
