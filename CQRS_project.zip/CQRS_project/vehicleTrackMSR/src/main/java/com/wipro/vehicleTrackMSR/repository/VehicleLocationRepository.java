package com.wipro.vehicleTrackMSR.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.wipro.vehicleTrackMSR.entity.VehicleLocation;

public interface VehicleLocationRepository extends JpaRepository<VehicleLocation, Integer> {

}
