package com.wipro.vehicleTrackMSR.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.wipro.vehicleTrackMSR.entity.VehicleLocation;
import com.wipro.vehicleTrackMSR.service.VehicleLocationService;

@RestController
@RequestMapping("/vehicleLocation")
public class VehicleLocationController {

    @Autowired
    private VehicleLocationService vehicleLocationService;

    @GetMapping("/all")
    public List<VehicleLocation> getAllLocations() {
        return vehicleLocationService.getAllLocations();
    }

    @GetMapping("/{id}")
    public VehicleLocation getLocationById(@PathVariable Integer id) {
        return vehicleLocationService.getLocationById(id);
    }
}
