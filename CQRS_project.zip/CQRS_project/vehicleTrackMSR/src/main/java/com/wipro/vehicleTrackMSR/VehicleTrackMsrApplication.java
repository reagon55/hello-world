package com.wipro.vehicleTrackMSR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleTrackMsrApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleTrackMsrApplication.class, args);
	}

}
