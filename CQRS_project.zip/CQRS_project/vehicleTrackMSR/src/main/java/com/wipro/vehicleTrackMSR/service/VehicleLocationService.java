package com.wipro.vehicleTrackMSR.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wipro.vehicleTrackMSR.entity.VehicleLocation;
import com.wipro.vehicleTrackMSR.repository.VehicleLocationRepository;

@Service
public class VehicleLocationService {

    @Autowired
    private VehicleLocationRepository vehicleLocationRepository;

    public List<VehicleLocation> getAllLocations() {
        return vehicleLocationRepository.findAll();
    }

    public VehicleLocation getLocationById(Integer id) {
        Optional<VehicleLocation> optional = vehicleLocationRepository.findById(id);
        return optional.orElse(null);
    }
}
