package com.ecommerce.orderservice.service;

import com.ecommerce.orderservice.entity.Cart;
import com.ecommerce.orderservice.model.Product; // Yeh Product DTO banaya tha WebClient response ke liye
import com.ecommerce.orderservice.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private WebClient.Builder webClientBuilder; // WebClient injected

    public Product fetchProduct(Integer productId) {
        return webClientBuilder.build()
                .get()
                .uri("http://localhost:8082/product/" + productId)
                .retrieve()
                .bodyToMono(Product.class)
                .blockOptional()
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));
    }


    // Method to fetch product details from ProductService
//    public Product fetchProductById(Integer productId) {
//        return webClientBuilder.build()
//                .get()
//                .uri("http://localhost:8082/product/" + productId) // ProductService ka URL
//                .retrieve()
//                .bodyToMono(Product.class)
//                .block(); // Synchronous call for now
//    }

    // Add products to cart


    public Cart addToCart(Integer userId, Map<Integer, Integer> products) {
        double totalPrice = 0.0;
        double totalQty = 0.0;

        for (Map.Entry<Integer, Integer> entry : products.entrySet()) {
            Integer productId = entry.getKey();
            Integer quantity = entry.getValue();

            Product product = fetchProduct(productId);

            if (product == null) {
                throw new RuntimeException("Product with ID " + productId + " not found!");
            }

//            if (product.getAvailableQty() == null) {
//                throw new RuntimeException("Available Quantity is not available for product ID: " + productId);
//            }

            if (product.getAvailableQty() < quantity) {
                throw new RuntimeException("Only " + product.getAvailableQty() + " items available for product ID: " + productId);
            }

            totalPrice += product.getPrice() * quantity;
            totalQty += quantity;
        }

        Cart cart = new Cart();
        cart.setUserId(userId);
        cart.setProductDetails(products);
        cart.setTotalPrice(totalPrice);
        cart.setTotalQty(totalQty);

        return cartRepository.save(cart);
    }





    // Get All Carts
    public List<Cart> getAllCarts() {
        return cartRepository.findAll();
    }

    // Get Cart by ID
    public Cart getCartById(Integer id) {
        return cartRepository.findById(id).orElse(null);
    }

    // Delete Cart by ID
    public String deleteCartById(Integer id) {
        cartRepository.deleteById(id);
        return "Cart deleted successfully!";
    }
}
