package com.ecommerce.orderservice.model;

import lombok.Data;
import java.util.Map;

@Data
public class AddToCartRequest {
    private Integer userId;
    private Map<Integer, Integer> productDetails; // productId -> quantity

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Map<Integer, Integer> getProductDetails() {
        return productDetails;
    }

    public void setProductDetails(Map<Integer, Integer> productDetails) {
        this.productDetails = productDetails;
    }
}
