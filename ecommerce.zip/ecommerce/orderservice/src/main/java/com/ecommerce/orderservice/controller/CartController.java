package com.ecommerce.orderservice.controller;

import com.ecommerce.orderservice.entity.Cart;
import com.ecommerce.orderservice.model.AddToCartRequest;
import com.ecommerce.orderservice.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    // 1. Add to cart
    @PostMapping("/add")
    public Cart addToCart(@RequestParam Integer userId, @RequestBody AddToCartRequest request) {
        return cartService.addToCart(userId, request.getProductDetails());
    }

    // 2. Get all carts
    @GetMapping("/all")
    public List<Cart> getAllCarts() {
        return cartService.getAllCarts();
    }

    // 3. Get cart by ID
    @GetMapping("/{id}")
    public Cart getCartById(@PathVariable Integer id) {
        return cartService.getCartById(id);
    }

    // 4. Delete cart by ID
    @DeleteMapping("/delete/{id}")
    public String deleteCartById(@PathVariable Integer id) {
        return cartService.deleteCartById(id);
    }
}
