package com.ecommerce.productservice.service;

import com.ecommerce.productservice.entity.Product;
import com.ecommerce.productservice.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    public Product getProductById(int id) {
        return productRepository.findById(id).orElse(null);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product updateProduct(int id, Product updatedProduct) {
        Optional<Product> optionalProduct = productRepository.findById(id);
        if (optionalProduct.isPresent()) {
            Product existingProduct = optionalProduct.get();
            existingProduct.setProdName(updatedProduct.getProdName());
            existingProduct.setProdDesc(updatedProduct.getProdDesc());
            existingProduct.setAvailableQty(updatedProduct.getAvailableQty());
            existingProduct.setPrice(updatedProduct.getPrice());
            existingProduct.setProdRating(updatedProduct.getProdRating());
            existingProduct.setMake(updatedProduct.getMake());
            existingProduct.setWom(updatedProduct.getWom());
            existingProduct.setImageUrl(updatedProduct.getImageUrl());
            existingProduct.setProdCat(updatedProduct.getProdCat());
            existingProduct.setDateOfManufacture(updatedProduct.getDateOfManufacture());
            return productRepository.save(existingProduct);
        }
        return null;
    }

    public void deleteProduct(int id) {
        productRepository.deleteById(id);
    }
}
