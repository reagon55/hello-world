package com.wipro.accoduntservice.repository;

import com.wipro.accoduntservice.entity.AccountHolder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountHolderRepository extends JpaRepository<AccountHolder, Long> { }


