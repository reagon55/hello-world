package com.wipro.accoduntservice.controller;

import com.wipro.accoduntservice.entity.AccountHolder;
import com.wipro.accoduntservice.repository.AccountHolderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/accounts")
public class AccountHolderController {

    @Autowired
    private AccountHolderRepository accountHolderRepository;

    @PostMapping
    public AccountHolder createHolder(@RequestBody AccountHolder holder) {
        return accountHolderRepository.save(holder);
    }

    @GetMapping("/{id}")
    public AccountHolder getHolder(@PathVariable Long id) {
        return accountHolderRepository.findById(id).orElse(null);
    }
}
