package com.wipro.mylambda;

public record Response(String answer) {}