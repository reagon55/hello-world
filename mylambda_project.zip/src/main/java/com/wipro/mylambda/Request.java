package com.wipro.mylambda;

public record Request(String name, String question) {}