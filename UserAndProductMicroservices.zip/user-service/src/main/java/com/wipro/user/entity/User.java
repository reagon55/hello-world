package com.wipro.user.entity;

public class User {
    private int id;
    private String firstName;
    private String lastName;
    private String emailId;
    private String userId;
    private String password; // encrypted
    private String address;
    private int userType; // 0-admin, 1-customer

    // Getters and Setters
}
