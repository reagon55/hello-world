package com.wipro.product.entity;

import java.time.LocalDate;

public class Product {
    private int id;
    private String prodName;
    private String prodDesc;
    private String prodCat;
    private String make;
    private int availableQty;
    private double price;
    private String warranty;
    private double prodRating;
    private String imageURL;
    private LocalDate dateOfManufacture;

    // Getters and Setters
}
