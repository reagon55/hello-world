package com.wipro.pagination.paginationDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaginationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
