package com.wipro.pagination.paginationDemo.controller;

import com.wipro.pagination.paginationDemo.entity.Product;
import com.wipro.pagination.paginationDemo.service.ProdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;

@RestController
@RequestMapping("/product")
public class ProdController {
@Autowired
ProdService prodService;
@GetMapping
List<Product> findAll()
{
return prodService.findAll();
}
@GetMapping("/{prop}")
List<Product> findByProp(@PathVariable String prop)
{
return prodService.findAllSortBy(prop);
}
@GetMapping("/{offset}/{pageSize}")
Page<Product> findAllPaginate(@PathVariable int offset, @PathVariable int  pageSize)
{
System.out.println("pageSize="+pageSize);
return prodService.findAllPaginate(offset, pageSize);
}
@GetMapping("/{fieldName}/{offset}/{pageSize}")
Page<Product> findAllPaginate(@PathVariable String fieldName,@PathVariable int offset,@PathVariable int  pageSize)
{
System.out.println("fieldName="+fieldName);
return prodService.findAllPaginateWithSort(offset, pageSize,fieldName);
}
 
}
