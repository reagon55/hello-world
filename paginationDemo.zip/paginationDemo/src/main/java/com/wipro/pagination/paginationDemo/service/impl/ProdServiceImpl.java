package com.wipro.pagination.paginationDemo.service.impl;

import com.wipro.pagination.paginationDemo.entity.Product;
import com.wipro.pagination.paginationDemo.repo.ProdRepo;
import com.wipro.pagination.paginationDemo.service.ProdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdServiceImpl implements ProdService {
 
@Autowired
ProdRepo prodRepo;
//  @PostConstruct
//  void initDb()
//  {
//    List<Product> prodList=IntStream
//    .rangeClosed(1, 1000)
//    .mapToObj(i->new Product("prod-"+i,"prodcat-"+i,Math.random()))
//    .toList();
//    prodRepo.saveAll(prodList);
//    
//    
//    
//  } 
@Override
public List<Product> findAll() {
// TODO Auto-generated method stub
return prodRepo.findAll();
}
 
@Override
public List<Product> findAllSortBy(String fieldName) {
// TODO Auto-generated method stub
return prodRepo.findAll(Sort.by(Sort.Direction.ASC,fieldName));
}
 
@Override
public Page<Product> findAllPaginate(int offset, int pageSeize) {
// TODO Auto-generated method stub 
Page<Product> prodPage=prodRepo.findAll(PageRequest.of(offset, pageSeize));
return prodPage;
}
 
@Override
public Page<Product> findAllPaginateWithSort(int offset, int pageSeize, String fieldName) {
// TODO Auto-generated method stub
return prodRepo.findAll(PageRequest.of(offset, pageSeize).withSort(Sort.by(Sort.Direction.DESC,fieldName)));
}
 
 
}
 
