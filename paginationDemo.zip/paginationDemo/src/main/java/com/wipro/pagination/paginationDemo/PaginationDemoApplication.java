package com.wipro.pagination.paginationDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginationDemoApplication.class, args);
	}

}
