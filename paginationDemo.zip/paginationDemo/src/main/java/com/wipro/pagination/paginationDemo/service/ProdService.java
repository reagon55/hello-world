package com.wipro.pagination.paginationDemo.service;

import com.wipro.pagination.paginationDemo.entity.Product;
import org.springframework.data.domain.Page;

import java.util.List;

public interface ProdService {
 
List<Product> findAll();
List<Product> findAllSortBy(String fieldName);
Page<Product> findAllPaginate(int offset, int pageSeize);
Page<Product> findAllPaginateWithSort(int offset,int pageSeize,String fieldName);

}
